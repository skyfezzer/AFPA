--/***************************************************************
--Script req_delice_TODO.sql
--***************************************************************/
-- On interprete  les &  comme variable de substitution
set define on

-- affichage des substitutions de variable
set verify on

--2.1.1
