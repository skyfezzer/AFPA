/***********************************************************************
 * Module:  FenetreMenuPrincipal.java
 * Author:  Sk
 * Purpose: Defines the Class FenetreMenuPrincipal
 ***********************************************************************/

package vueLogique.biblio_ui;

import java.util.*;

/** @pdOid 7356b004-bf88-4726-861e-930e9040cb50 */
public class FenetreMenuPrincipal {
}