/***********************************************************************
 * Module:  FenetreRecapEmprunt.java
 * Author:  Sk
 * Purpose: Defines the Class FenetreRecapEmprunt
 ***********************************************************************/

package vueLogique.biblio_ui;

import java.util.*;

/** @pdOid a152ca92-3557-4c73-8c46-31cea70c99b0 */
public class FenetreRecapEmprunt {
}