/***********************************************************************
 * Module:  FenetreNouvelEmprunt.java
 * Author:  Sk
 * Purpose: Defines the Class FenetreNouvelEmprunt
 ***********************************************************************/

package vueLogique.biblio_ui;

import java.util.*;

/** @pdOid c91e3b11-7ae6-427d-92bf-c703f274aa0e */
public final class FenetreNouvelEmprunt {
   /** @param pret
    * @pdOid d233afed-11c5-4e1c-92e7-503d0668e621 */
   public int afficheResume(Pret pret) {
      // TODO: implement
      return 0;
   }

}