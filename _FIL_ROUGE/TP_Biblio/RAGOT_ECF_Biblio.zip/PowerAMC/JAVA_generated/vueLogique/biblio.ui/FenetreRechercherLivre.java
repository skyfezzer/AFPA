/***********************************************************************
 * Module:  FenetreRechercherLivre.java
 * Author:  Sk
 * Purpose: Defines the Class FenetreRechercherLivre
 ***********************************************************************/

package vueLogique.biblio_ui;

import java.util.*;

/** @pdOid b4f3056a-2185-43a9-9fa3-55184e72994b */
public class FenetreRechercherLivre {
}