/***********************************************************************
 * Module:  FenetreGestionEmprunts.java
 * Author:  Sk
 * Purpose: Defines the Class FenetreGestionEmprunts
 ***********************************************************************/

package vueLogique.biblio_ui;

import java.util.*;

/** @pdOid 6a40e46f-1fc9-4ed9-8379-63298304564c */
public class FenetreGestionEmprunts {
}