/***********************************************************************
 * Module:  FenetreListeLivres.java
 * Author:  Sk
 * Purpose: Defines the Class FenetreListeLivres
 ***********************************************************************/

package vueLogique.biblio_ui;

import java.util.*;

/** @pdOid 7bff42b0-ec27-4680-91b1-f2604fb06070 */
public class FenetreListeLivres {
}