/***********************************************************************
 * Module:  FenetreConnexion.java
 * Author:  Sk
 * Purpose: Defines the Class FenetreConnexion
 ***********************************************************************/

package vueLogique.biblio_ui;

import java.util.*;

/** @pdOid 50f4cfb1-097b-4013-82e9-aa0d1dd3a22a */
public class FenetreConnexion {
}