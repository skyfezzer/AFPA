/***********************************************************************
 * Module:  SeConnecterControler.java
 * Author:  Sk
 * Purpose: Defines the Class SeConnecterControler
 ***********************************************************************/

package vueLogique.biblio_controller;

import java.util.*;

/** @pdOid c5a056e1-e0c0-4c62-8c2d-54ec2ffb2451 */
public class SeConnecterControler {
   /** @param pin
    * @pdOid 3c9e2864-9927-4508-97d2-8a8414953053 */
   public boolean isPinOK(String pin) {
      // TODO: implement
      return false;
   }

}