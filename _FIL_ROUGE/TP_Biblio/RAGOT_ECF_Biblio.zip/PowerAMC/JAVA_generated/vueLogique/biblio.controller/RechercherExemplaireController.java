/***********************************************************************
 * Module:  RechercherExemplaireController.java
 * Author:  Sk
 * Purpose: Defines the Class RechercherExemplaireController
 ***********************************************************************/

package vueLogique.biblio_controller;

import java.util.*;

/** @pdOid 1ba46143-9909-482f-a395-c4ee92fa6b8b */
public class RechercherExemplaireController {
   /** @pdOid 01341bc1-6ce3-43d0-9531-c4044b68a2df */
   public String getTitre() {
      // TODO: implement
      return null;
   }
   
   /** @param livre
    * @pdOid 62e68449-3633-40fb-a23c-83137ac66bcc */
   public Exemplaire getExemplaireFromLivre(Livre livre) {
      // TODO: implement
      return null;
   }

}