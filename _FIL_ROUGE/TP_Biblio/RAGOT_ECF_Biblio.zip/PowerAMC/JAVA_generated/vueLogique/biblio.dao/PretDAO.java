/***********************************************************************
 * Module:  PretDAO.java
 * Author:  Sk
 * Purpose: Defines the Class PretDAO
 ***********************************************************************/

package vueLogique.biblio_dao;

import vueLogique.biblio_domain.Pret;
import vueLogique.biblio_domain.Utilisateur;
import java.util.*;

/** @pdOid 182fef41-734d-4d62-80ed-0888f633123a */
public class PretDAO {
   /** @param utilisateur
    * @pdOid 66b57312-044b-40a4-95b5-0619ab5cabe5 */
   public Pret[] findAllPretsByUtilisateur(Utilisateur utilisateur) {
      // TODO: implement
      return null;
   }
   
   /** @param pret
    * @pdOid 5579e1da-8997-429d-88d8-d6080f77177d */
   public int insertPret(Pret pret) {
      // TODO: implement
      return 0;
   }

}