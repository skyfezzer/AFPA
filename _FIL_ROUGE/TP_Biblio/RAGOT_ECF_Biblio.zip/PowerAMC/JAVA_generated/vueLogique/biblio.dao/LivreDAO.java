/***********************************************************************
 * Module:  LivreDAO.java
 * Author:  Sk
 * Purpose: Defines the Class LivreDAO
 ***********************************************************************/

package vueLogique.biblio_dao;

import vueLogique.biblio_domain.Livre;
import java.util.*;

/** @pdOid 16fc22dd-2cd2-438d-b256-b30356e219ed */
public class LivreDAO {
   /** @param contains
    * @pdOid 42ae3960-8ca9-4c08-8fd8-354005fb1a86 */
   public Livre[] findMatchesByTitre(String contains) {
      // TODO: implement
      return null;
   }
   
   /** @param isbn
    * @pdOid 355c38d6-a303-4c8c-9fee-2729abf3e96f */
   public Livre findLivreByKey(int isbn) {
      // TODO: implement
      return null;
   }

}