/***********************************************************************
 * Module:  ExemplaireDAO.java
 * Author:  Sk
 * Purpose: Defines the Class ExemplaireDAO
 ***********************************************************************/

package vueLogique.biblio_dao;

import vueLogique.biblio_domain.Livre;
import java.util.*;

/** @pdOid 497bdfbf-e909-4a15-a7ff-c9b904c05060 */
public class ExemplaireDAO {
   /** @param leLivre
    * @pdOid b6d1165a-d6b5-43d6-ae40-25d7bb18d9f9 */
   public Exemplaire[] findExemplairesByLivre(Livre leLivre) {
      // TODO: implement
      return null;
   }
   
   /** @param leLivre 
    * @param noExemplaire
    * @pdOid f4874ef9-21ce-4c3f-a120-43cc8d4a4242 */
   public Exemplaire findExemplaireByKey(Livre leLivre, int noExemplaire) {
      // TODO: implement
      return null;
   }

}