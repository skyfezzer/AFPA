/***********************************************************************
 * Module:  EmplacementDAO.java
 * Author:  Sk
 * Purpose: Defines the Class EmplacementDAO
 ***********************************************************************/

package vueLogique.biblio_dao;

import java.util.*;

/** @pdOid 199890c8-a608-4cb8-b5a6-e71cf9cd76f3 */
public class EmplacementDAO {
}