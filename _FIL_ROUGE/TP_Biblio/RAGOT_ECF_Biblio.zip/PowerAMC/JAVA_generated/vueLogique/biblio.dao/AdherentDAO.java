/***********************************************************************
 * Module:  AdherentDAO.java
 * Author:  Sk
 * Purpose: Defines the Class AdherentDAO
 ***********************************************************************/

package vueLogique.biblio_dao;

import vueLogique.biblio_domain.Adherent;
import java.util.*;

/** @pdOid 0fdc4bb2-3cdf-4fdb-aa0b-ae5e51539c06 */
public class AdherentDAO {
   /** @param noAdherent
    * @pdOid 9d010179-fb09-4469-a532-0176a58d0987 */
   public Adherent findAdherentByKey(int noAdherent) {
      // TODO: implement
      return null;
   }

}