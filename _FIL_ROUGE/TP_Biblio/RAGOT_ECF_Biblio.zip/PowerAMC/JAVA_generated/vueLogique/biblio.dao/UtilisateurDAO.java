/***********************************************************************
 * Module:  UtilisateurDAO.java
 * Author:  Sk
 * Purpose: Defines the Class UtilisateurDAO
 ***********************************************************************/

package vueLogique.biblio_dao;

import java.util.*;

/** @pdOid 0b3bf29d-62a0-4bf3-92ad-680c39ca7af2 */
public class UtilisateurDAO {
   /** @param noAdherent
    * @pdOid b3684116-0eff-404f-ac5b-d50134034b34 */
   public Utilisateur findByKey(int noAdherent) {
      // TODO: implement
      return null;
   }
   
   /** @param pincode
    * @pdOid 6a5d0553-6ad2-42db-a333-573df5b35ac1 */
   public boolean isPinOK(String pincode) {
      // TODO: implement
      return false;
   }

}