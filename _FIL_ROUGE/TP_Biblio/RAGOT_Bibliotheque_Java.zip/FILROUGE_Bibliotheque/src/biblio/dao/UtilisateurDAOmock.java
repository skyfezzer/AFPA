/***********************************************************************
 * Module:  UtilisateurDAO.java
 * Author:  Sk
 * Purpose: Defines the Class UtilisateurDAO
 ***********************************************************************/

package biblio.dao;

import java.util.*;

import biblio.domain.Adherent;
import biblio.domain.Utilisateur;

/** @pdOid 0b3bf29d-62a0-4bf3-92ad-680c39ca7af2 */
public class UtilisateurDAOmock {
	/*private int compteur = 1;
	private Utilisateur [] utilisateursDB = {
			new Adherent(compteur++, "ALEXIS","RAGOT","05.21.15.51.86","iseeHeehai8"),
			new Adherent(compteur++,"Guy","Labbé","01.88.70.79.25","phiiweip1iD"),
			new Adherent(compteur++,"Musette","Chalut","02.17.46.14.56","Maighud6nu"),
			new Adherent(compteur++,"Nathalie","Briard","01.68.54.77.42","ahj7eu3A"),
			new Adherent(compteur++,"Solaine","Baril","01.82.36.99.30","PohBah1eesu"),
			new Adherent(compteur++,"Ignace","Bélair","04.10.03.31.77","Kaide5keing"),
			new Adherent(compteur++,"Aubrey","Moreau","01.16.13.25.80","Uosh4ahvei"),
			new Adherent(compteur++,"Dielle","L'Heureux","01.90.49.33.49","zieXoon9ae"),
			new Adherent(compteur++,"Catherine","LaGrande","02.98.41.82.87","IeT8buzei"),
			new Adherent(compteur++,"Phillipa","Clavette","01.31.07.65.76","xoo0Yeequ")
	};
	public Utilisateur findByKey(int noAdherent) {
		for(Utilisateur user:utilisateursDB) {
			if(user.getNoPersonne() == noAdherent)
				return user;
		}
		// Exception utilisateur inconnu
		return null;
	}*/
	
	

}